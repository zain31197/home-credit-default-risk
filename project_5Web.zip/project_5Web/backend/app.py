from flask import Flask, jsonify, send_from_directory
import pandas as pd
import os

app = Flask(__name__)

PREDICTED_CSV_PATH = os.path.join("predicted", "predicted_results.csv")

@app.route("/api/predictions")
def get_predictions():
    if not os.path.exists(PREDICTED_CSV_PATH):
        return jsonify({"error": "Prediction file not found"}), 404

    df = pd.read_csv(PREDICTED_CSV_PATH)
    df.fillna("-", inplace=True)  # for display safety
    records = df.to_dict(orient="records")

    # Pie chart data
    target_counts = df['TARGET'].value_counts().to_dict()

    return jsonify({"data": records, "chart": target_counts})


# Serve frontend
@app.route("/")
def serve_ui():
    return send_from_directory("../frontend", "index.html")


@app.route("/<path:path>")
def serve_static(path):
    return send_from_directory("../frontend", path)


if __name__ == "__main__":
    app.run(debug=True)
