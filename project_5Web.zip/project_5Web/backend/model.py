import pandas as pd
import numpy as np
import joblib
import os
from sklearn.preprocessing import OrdinalEncoder, LabelEncoder

TOP_FEATURES = [
    'EXT_SOURCES_MEAN', 'EXT_SOURCE_3', 'EXT_SOURCE_2', 'EXT_SOURCE_1',
    'DAYS_BIRTH', 'REJECTION_RATE', 'EDUCATION_ORD', 'REGION_RATING_CLIENT_W_CITY',
    'DAYS_LAST_PHONE_CHANGE', 'REGION_RATING_CLIENT', 'CODE_GENDER',
    'DAYS_ID_PUBLISH', 'NAME_INCOME_TYPE', 'FLAG_EMP_PHONE'
]

# -------------------------- Load & Aggregate External Data --------------------------

def load_and_aggregate():
    data_dir = os.path.join(os.path.dirname(__file__), "data")

    bb  = pd.read_csv(os.path.join(data_dir, "bureau_balance.csv"))
    b   = pd.read_csv(os.path.join(data_dir, "bureau.csv"))
    pa  = pd.read_csv(os.path.join(data_dir, "previous_application.csv"))
    pcb = pd.read_csv(os.path.join(data_dir, "POS_CASH_balance.csv"))
    ccb = pd.read_csv(os.path.join(data_dir, "credit_card_balance.csv"))
    ip  = pd.read_csv(os.path.join(data_dir, "installments_payments.csv"))

    status_map = {'C': 0, '0': 0, 'X': 0, '1': 1, '2': 2, '3': 3, '4': 4, '5': 5}
    bb["STATUS_NUM"] = bb["STATUS"].map(status_map)

    bb_agg = bb.groupby("SK_ID_BUREAU").agg(
        MONTHS_COUNT=("MONTHS_BALANCE", "size"),
        WORST_STATUS=("STATUS_NUM", "max"),
        AVG_STATUS=("STATUS_NUM", "mean")
    ).reset_index()

    b2 = b.merge(bb_agg, on="SK_ID_BUREAU", how="left")
    bureau_agg = b2.groupby("SK_ID_CURR").agg(
        BUREAU_COUNT=("SK_ID_BUREAU", "size"),
        AVG_CREDIT_SUM=("AMT_CREDIT_SUM", "mean"),
        MAX_OVERDUE=("CREDIT_DAY_OVERDUE", "max"),
        BUREAU_WORST_STATUS=("WORST_STATUS", "max")
    ).reset_index()

    pa_agg = pa.groupby("SK_ID_CURR").agg(
        PREV_COUNT=("SK_ID_PREV", "size"),
        AVG_PREV_AMT=("AMT_CREDIT", "mean"),
        REJECTION_RATE=("NAME_CONTRACT_STATUS", lambda s: (s == "Refused").mean())
    ).reset_index()

    pos_agg = pcb.groupby("SK_ID_CURR").agg(
        POS_AVG_BALANCE=("MONTHS_BALANCE", "mean"),
        POS_MAX_DPD=("SK_DPD", "max")
    ).reset_index()

    cc_agg = ccb.groupby("SK_ID_CURR").agg(
        CC_AVG_BALANCE=("AMT_BALANCE", "mean"),
        CC_UTILIZATION_RATE=("AMT_CREDIT_LIMIT_ACTUAL",
                             lambda x: (x.sum() - x.mean()) / x.sum() if x.sum() > 0 else 0)
    ).reset_index()

    ip["PAY_DIFF"] = ip["AMT_INSTALMENT"] - ip["AMT_PAYMENT"]
    ip["DELAY_DAYS"] = ip["DAYS_ENTRY_PAYMENT"] - ip["DAYS_INSTALMENT"]
    ip_agg = ip.groupby("SK_ID_CURR").agg(
        INSTL_AVG_PAY_DIFF=("PAY_DIFF", "mean"),
        INSTL_MAX_DELAY=("DELAY_DAYS", "max")
    ).reset_index()

    return bureau_agg, pa_agg, pos_agg, cc_agg, ip_agg

bureau_agg, pa_agg, pos_agg, cc_agg, ip_agg = load_and_aggregate()

def merge_main(df):
    df = df.merge(bureau_agg, on="SK_ID_CURR", how="left")
    df = df.merge(pa_agg, on="SK_ID_CURR", how="left")
    df = df.merge(pos_agg, on="SK_ID_CURR", how="left")
    df = df.merge(cc_agg, on="SK_ID_CURR", how="left")
    df = df.merge(ip_agg, on="SK_ID_CURR", how="left")
    return df

# -------------------------- Feature Engineering --------------------------

def add_features(df):
    new_features = pd.DataFrame({
        "INCOME_PER_PERSON": df["AMT_INCOME_TOTAL"] / df["CNT_FAM_MEMBERS"],
        "ANNUITY_INCOME_RATIO": df["AMT_ANNUITY"] / df["AMT_INCOME_TOTAL"],
        "CREDIT_INCOME_RATIO": df["AMT_CREDIT"] / df["AMT_INCOME_TOTAL"],
        "EMPLOYED_TO_BIRTH_RATIO": df["DAYS_EMPLOYED"] / df["DAYS_BIRTH"],
        "EXT_SOURCES_MEAN": df[["EXT_SOURCE_1", "EXT_SOURCE_2", "EXT_SOURCE_3"]].mean(axis=1)
    }, index=df.index)

    # Concatenate all new columns at once to avoid fragmentation
    df = pd.concat([df, new_features], axis=1)
    return df

def ordinal_to_num(df):
    education_order = [
        'Lower secondary', 'Secondary / secondary special', 'Incomplete higher',
        'Higher education', 'Academic degree'
    ]
    family_status_order = [
        'Unknown', 'Separated', 'Widow', 'Single / not married',
        'Civil marriage', 'Married'
    ]
    df["NAME_EDUCATION_TYPE"] = df["NAME_EDUCATION_TYPE"].fillna("Lower secondary")
    df["NAME_FAMILY_STATUS"] = df["NAME_FAMILY_STATUS"].fillna("Unknown")
    encoder = OrdinalEncoder(categories=[education_order, family_status_order])
    df[["EDUCATION_ORD", "FAMILY_STATUS_ORD"]] = encoder.fit_transform(
        df[["NAME_EDUCATION_TYPE", "NAME_FAMILY_STATUS"]]
    )
    return df

def label_encode(df):
    cat_cols = df.select_dtypes(include=["object"]).columns.tolist()
    for col in ["NAME_EDUCATION_TYPE", "NAME_FAMILY_STATUS"]:
        if col in cat_cols:
            cat_cols.remove(col)
    for col in cat_cols:
        df[col] = df[col].astype(str)
        le = LabelEncoder()
        df[col] = le.fit_transform(df[col])
    return df

# -------------------------- Prediction Entry Point --------------------------

def predict_labels(df):
    df = df.copy()

    # Merge external tables
    df = merge_main(df)

    # Preprocessing
    df = ordinal_to_num(df)
    df = label_encode(df)
    df = df.fillna(df.mean(numeric_only=True))
    df = add_features(df)

    # Feature selection
    missing_features = [col for col in TOP_FEATURES if col not in df.columns]
    if missing_features:
        raise ValueError(f"Missing required features: {missing_features}")

    X = df[TOP_FEATURES]

    # Load model
    model_path = os.path.join(os.path.dirname(__file__), 'loan_default_model_DTC.pkl')
    model = joblib.load(model_path)

    # Predict
    predictions = model.predict(X)

    df = pd.concat([df, pd.DataFrame({
        "PREDICTED": predictions
    }, index=df.index)], axis=1)

    return df
