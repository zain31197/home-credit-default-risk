fetch("/api/predictions")
    .then(res => res.json())
    .then(response => {
        const data = response.data;
        const chart = response.chart;

        // Columns to include in the table (order matters)
        const TOP_FEATURES = [
            'EXT_SOURCE_1',
            'DAYS_BIRTH', 'REJECTION_RATE', 'EDUCATION_ORD',
            'CODE_GENDER',
            'NAME_INCOME_TYPE'
        ];

        // Final order: ID first, then top features, then prediction
        const CUSTOM_COLUMNS = ['SK_ID_CURR', ...TOP_FEATURES, 'TARGET'];

        // Filter raw data to keep only selected columns
        const filteredData = data.map(row => {
            const newRow = {};
            CUSTOM_COLUMNS.forEach(col => {
                newRow[col] = row[col] !== undefined ? row[col] : '-';
            });
            return newRow;
        });

        // Define DataTable columns
        const columns = CUSTOM_COLUMNS.map(col => ({
            title: col,
            data: col
        }));

        // Initialize DataTable
        $(document).ready(function () {
            $('#result-table').DataTable({
                data: filteredData,
                columns: columns,
                pageLength: 10,
                createdRow: function (row, rowData) {
                    if (rowData.TARGET == 1) {
                        $(row).addClass('row-target-1');
                    } else if (rowData.TARGET == 0) {
                        $(row).addClass('row-target-0');
                    }
                }
            });
        });

        // ----- Pie Chart for TARGET -----
        new Chart(document.getElementById('targetChart'), {
            type: 'pie',
            data: {
                labels: Object.keys(chart),
                datasets: [{
                    data: Object.values(chart),
                    backgroundColor: ['#36a2eb', '#ff6384']
                }]
            },
            options: {
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });

        // ----- Histogram: DAYS_BIRTH → Age
        const daysBirth = filteredData.map(row => row.DAYS_BIRTH)
            .filter(val => val !== "-" && val !== null && val !== "")
            .map(val => Math.floor(Math.abs(val) / 365));  // convert to age

        const ageBuckets = {};
        daysBirth.forEach(age => {
            ageBuckets[age] = (ageBuckets[age] || 0) + 1;
        });

        new Chart(document.getElementById('birthChart'), {
            type: 'bar',
            data: {
                labels: Object.keys(ageBuckets),
                datasets: [{
                    label: 'Age Distribution',
                    data: Object.values(ageBuckets),
                    backgroundColor: '#42a5f5'
                }]
            },
            options: {
                responsive: true,
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Age (Years)'
                        }
                    },
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // ----- Bar Chart: EXT_SOURCE_1
        const ext1 = filteredData.map(row => row.EXT_SOURCE_1)
            .filter(v => v !== "-" && v !== null && v !== "")
            .map(v => parseFloat(v).toFixed(1));

        const source1Buckets = {};
        ext1.forEach(val => {
            source1Buckets[val] = (source1Buckets[val] || 0) + 1;
        });

        new Chart(document.getElementById('source1Chart'), {
            type: 'bar',
            data: {
                labels: Object.keys(source1Buckets),
                datasets: [{
                    label: 'EXT_SOURCE_1 Frequency',
                    data: Object.values(source1Buckets),
                    backgroundColor: '#66bb6a'
                }]
            },
            options: {
                responsive: true,
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'EXT_SOURCE_1 (Rounded)'
                        }
                    },
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    });
